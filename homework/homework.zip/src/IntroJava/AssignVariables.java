package IntroJava;

public class AssignVariables {
}
