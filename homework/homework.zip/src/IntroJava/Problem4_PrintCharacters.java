package IntroJava;

public class Problem4_PrintCharacters {
    public static void main(String[] args) {
        for (char c = 'a'; c <= 'z'; c++) {
            System.out.print((char)c);
            System.out.print(' ');
        }
    }
}
