package IntroJava;

public class Problem3_AssignVariables {
    public static void main(String[] args) {
        boolean firstVariable = false;
        String secondVariable = "Palo Alto, CA";
        short thirdVariable = 32767;
        int forthVariable = 2000000000;
        double fifthVariable = 0.1234567891011;
        float sixthVariable = 0.5f;
        long seventhVariable = 919827112351L;
        byte eithVariable = 127;
        char ninthVariable = 'c';
        //short testVariable = 32768; - not working
    }
}
