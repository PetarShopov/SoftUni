package IntroJava;

public class PrintCharacters {
}
